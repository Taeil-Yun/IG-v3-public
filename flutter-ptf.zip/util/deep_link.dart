import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:iget_v3/costant/build_config.dart';

class DeepLinkBuilder {
  Future<String> getShortLink(String screenName, String id) async {
    String dynamicLinkPrefix = IgetBuildConfig.instance?.buildType == 'dev' ? 'https://deeplink.i-get.biz' : 'https://app.i-get.link/igetappstore';

    final dynamicLinkParams = DynamicLinkParameters(
      uriPrefix: dynamicLinkPrefix,
      // link: Uri.parse('$dynamicLinkPrefix/$screenName?id=$id'),
      link: Uri.parse('$dynamicLinkPrefix/$screenName?id=$id'),
      androidParameters: AndroidParameters(
        packageName: IgetBuildConfig.instance?.buildType == 'dev' ? 'biz.iget.www' : 'com.iget.www',
      ),
      iosParameters: IOSParameters(
        bundleId: IgetBuildConfig.instance?.buildType == 'dev' ? 'biz.iget.www' : 'net.iget.www',
      ),
    );
    final dynamicLink = await FirebaseDynamicLinks.instance.buildShortLink(dynamicLinkParams);

    return dynamicLink.shortUrl.toString();
    // return '${dynamicLinkParams.link}';
  }

  Future<String> getShortLinkShare(String screenName, String id, String type) async {
    String dynamicLinkPrefix = IgetBuildConfig.instance?.buildType == 'dev' ? 'https://deeplink.i-get.biz' : 'https://app.i-get.link/igetappstore';

    final dynamicLinkParams = DynamicLinkParameters(
      uriPrefix: dynamicLinkPrefix,
      // link: Uri.parse('$dynamicLinkPrefix/$screenName?id=$id'),
      link: Uri.parse('$dynamicLinkPrefix/$screenName?id=$id&type=$type'),
      androidParameters: AndroidParameters(
        packageName: IgetBuildConfig.instance?.buildType == 'dev' ? 'biz.iget.www' : 'com.iget.www',
      ),
      iosParameters: IOSParameters(
        bundleId: IgetBuildConfig.instance?.buildType == 'dev' ? 'biz.iget.www' : 'net.iget.www',
      ),
    );
    final dynamicLink = await FirebaseDynamicLinks.instance.buildShortLink(dynamicLinkParams);

    return dynamicLink.shortUrl.toString();
    // return '${dynamicLinkParams.link}';
  }
}