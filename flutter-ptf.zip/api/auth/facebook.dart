import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import 'package:iget_v3/costant/build_config.dart';

class IgetLoginWithFacebookAPI {
  Future<IgetLoginWithFacebookAPIResponseModel> facebook({required String fbToken, required String fcmToken}) async {
    final baseUri = Uri.parse('${IgetBuildConfig.instance?.baseUrl}/auth/facebook/${Platform.isAndroid ? 'android' : 'ios'}');

    final response = await http.post(
      baseUri,
      headers: {
        // "Content-Type" : "application/json",
      },
      body: {
        "id_token": fbToken,
        "fcm_token": fcmToken,
      },
    );

    if (response.statusCode == 200) {
      // print('data: ${response.body}');

      return IgetLoginWithFacebookAPIResponseModel.fromJson(json.decode(utf8.decode(response.bodyBytes.toList())));
    } else {
      throw Exception(response.body);
    }
  }
}

class IgetLoginWithFacebookAPIResponseModel {
  dynamic result;

  IgetLoginWithFacebookAPIResponseModel({
    this.result,
  });

  factory IgetLoginWithFacebookAPIResponseModel.fromJson(Map<String, dynamic> data) {
    return IgetLoginWithFacebookAPIResponseModel(
      result: data,
    );
  }
}