import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import 'package:iget_v3/costant/build_config.dart';

class IgetLoginWithGoogleAPI {
  Future<IgetLoginWithGoogleAPIResponseModel> google({required String idToken, required String fcmToken}) async {
    final baseUri = Uri.parse('${IgetBuildConfig.instance?.baseUrl}/auth/google/${Platform.isAndroid ? 'android' : 'ios'}');

    final response = await http.post(
      baseUri,
      headers: {
        // "Content-Type" : "application/json",
      },
      body: {
        "id_token": idToken,
        "fcm_token": fcmToken,
      },
    );

    if (response.statusCode == 200) {
      // print('datas: ${utf8.decode(response.bodyBytes.toList())}');

      return IgetLoginWithGoogleAPIResponseModel.fromJson(json.decode(utf8.decode(response.bodyBytes.toList())));
    } else {
      throw Exception(response.body);
    }
  }
}

class IgetLoginWithGoogleAPIResponseModel {
  dynamic result;

  IgetLoginWithGoogleAPIResponseModel({
    this.result,
  });

  factory IgetLoginWithGoogleAPIResponseModel.fromJson(Map<String, dynamic> data) {
    return IgetLoginWithGoogleAPIResponseModel(
      result: data,
    );
  }
}
