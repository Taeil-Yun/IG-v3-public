import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import 'package:iget_v3/costant/build_config.dart';

class IgetLoginWithNaverAPI {
  Future<IgetLoginWithNaverAPIResponseModel> naver({required String naverToken, required String fcmToken}) async {
    final baseUri = Uri.parse('${IgetBuildConfig.instance?.baseUrl}/auth/naver/${Platform.isAndroid ? 'android' : 'ios'}');

    final response = await http.post(
      baseUri,
      headers: {
        // "Content-Type" : "application/json",
      },
      body: {
        "access_token": naverToken,
        "fcm_token": fcmToken,
      }

    );

    if (response.statusCode == 200) {
      // print('data: ${response.body}');

      return IgetLoginWithNaverAPIResponseModel.fromJson(json.decode(utf8.decode(response.bodyBytes.toList())));
    } else {
      throw Exception(response.body);
    }
  }
}

class IgetLoginWithNaverAPIResponseModel {
  dynamic result;

  IgetLoginWithNaverAPIResponseModel({
    this.result,
  });

  factory IgetLoginWithNaverAPIResponseModel.fromJson(Map<String, dynamic> data) {
    return IgetLoginWithNaverAPIResponseModel(
      result: data,
    );
  }
}