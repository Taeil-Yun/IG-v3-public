import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import 'package:iget_v3/costant/build_config.dart';

class IgetLoginWithAppleAPI {
  Future<IgetLoginWithAppleAPIResponseModel> apple({String? idToken, required String fcmToken}) async {
    final baseUri = Uri.parse('${IgetBuildConfig.instance?.baseUrl}/auth/apple/${Platform.isAndroid ? 'android' : 'ios'}');

    final response = await http.post(
      baseUri,
      headers: {
        // "Content-Type" : "application/json",
      },
      body: {
        "id_token": idToken,
        "fcm_token": fcmToken,
      },
    );

    if (response.statusCode == 200) {
      // print('datas: ${utf8.decode(response.bodyBytes.toList())}');

      return IgetLoginWithAppleAPIResponseModel.fromJson(json.decode(utf8.decode(response.bodyBytes.toList())));
    } else {
      throw Exception(response.body);
    }
  }
}

class IgetLoginWithAppleAPIResponseModel {
  dynamic result;

  IgetLoginWithAppleAPIResponseModel({
    this.result,
  });

  factory IgetLoginWithAppleAPIResponseModel.fromJson(Map<String, dynamic> data) {
    return IgetLoginWithAppleAPIResponseModel(
      result: data,
    );
  }
}
