import 'dart:convert';

import 'package:iget_v3/costant/build_config.dart';
import 'package:iget_v3/component/interceptor/interceptor.dart';

class AuctionDetailDataAPI {
  Future<AuctionDetailDataAPIResponseModel> auctionDetail({required String? accessToken, required int showIndex}) async {
    final baseUri = Uri.parse('${IgetBuildConfig.instance?.baseUrl}/auction/detail?show_detail_index=$showIndex');

    final response = await InterceptorHelper().client.get(
      baseUri,
      headers: {
        "Content-Type" : "application/json",
        "authorization" : "Bearer $accessToken",
      },
    );

    if (response.statusCode == 200) {
      // print('datas: ${utf8.decode(response.bodyBytes.toList())}');

      return AuctionDetailDataAPIResponseModel.fromJson(json.decode(utf8.decode(response.bodyBytes.toList())));
    } else if (response.statusCode == 402) {
      return AuctionDetailDataAPI().auctionDetail(accessToken: await SecureStorageConfig().storage.read(key: 'access_token'), showIndex: showIndex);
    } else {
      throw Exception(response.body);
    }
  }
}

class AuctionDetailDataAPIResponseModel {
  dynamic result;

  AuctionDetailDataAPIResponseModel({
    this.result,
  });

  factory AuctionDetailDataAPIResponseModel.fromJson(Map<String, dynamic> data) {
    return AuctionDetailDataAPIResponseModel(
      result: data,
    );
  }
}
