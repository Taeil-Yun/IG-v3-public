class IgetKeys {
  static const String kakaoProductNativeKey = '289edf95147349bd480666dd3e853888';
  static const String kakaoProductJavaScriptKey = '9fa3ce5d45dc68208bee5e5a38fccbae';
  static const String kakaoDevNativeKey = 'afd1bc0a0902dcb4fddc22c85bed13f2';
  static const String kakaoDevJavaScriptKey = '688314579909ce0f773b623d04313cb1';
  static const String googleProductClientIdKey = '11701135716-ua0hr44ia2tqih76ts4jmjll1ukvqlo8.apps.googleusercontent.com';
  static const String googleDevClientIdKey = '1015754652029-9ttrsg3kdrhkbdbrn5alcjst7i26l6d0.apps.googleusercontent.com';
  static const String channelTalkPluginKey = 'e5722b01-14e4-4f01-81cd-ea72fa5359e6';
  static const String channelTalkAccessKey = 'dd93601defbc40e348ee453a49fb5a59';
}