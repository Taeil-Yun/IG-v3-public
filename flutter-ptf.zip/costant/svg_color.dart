import 'package:flutter/material.dart';

const Color discountSvg = Color(0xFFff1b51);
const Color notificationDisabledBackgroundSvg = Color(0xFFc4c4d3);
const Color realReviewBadgeSvg = Color(0xFF572dff);