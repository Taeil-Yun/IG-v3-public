import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class IgetBuildConfig {
  final String baseUrl;
  final String acceessToken;
  String? buildType = '';

  IgetBuildConfig._dev():
    baseUrl = 'https://app.i-get.biz',
    acceessToken = '',
    buildType = 'dev';

  IgetBuildConfig._product():
    baseUrl = 'https://app.i-get.net',
    acceessToken = '',
    buildType = 'product';

  static IgetBuildConfig? instance;

  factory IgetBuildConfig (String? flavor) {
    if (flavor == 'dev') {
      instance = IgetBuildConfig._dev();
    } else if (flavor == 'product') {
      instance = IgetBuildConfig._product();
    } else {
      throw Exception("Unknown flaver : $flavor");
    }

    return instance!;
  }
}


class SecureStorageConfig {
  final FlutterSecureStorage storage;

  SecureStorageConfig._storage():
    storage = const FlutterSecureStorage(
      aOptions: AndroidOptions(
        encryptedSharedPreferences: true,
      ),
    );

  static SecureStorageConfig? instance;

  factory SecureStorageConfig () {
    instance = SecureStorageConfig._storage();

    return instance!;
  }
}